Converter for UAT-vs-live QA-log artifacts.
Run: python -I qa-tracker-converter/upgrade.py SOURCE.html OUT.html [--title "Name"]
Needs Python 3 and, for old pre-rendered pages, beautifulsoup4 (pip install beautifulsoup4).
